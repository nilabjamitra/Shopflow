package com.example.shopflowpage

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.example.shopflowpage.screen.Product
import com.example.shopflowpage.screen.ShopFlow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val sampleProducts = listOf(
                    Product(
                        id = "1",
                        name = "Clencera",
                        imageResId = R.drawable.categorysample,
                        isBestSeller = true,
                        category = "cleaner",
                        description = "Premium sound and comfort.",
                        originalPrice = "Rs.499",
                        discountedPrice = "Rs.399",
                        benefits = listOf("Skin Tightness", "Dry and dehydrated Skin"),
                        rating = 4.8f,
                        reviewCount = 1284
                    ),
                    Product(
                        id = "2",
                        name = "glow",
                        imageResId = R.drawable.categorysample,
                        isBestSeller = false,
                        category = "Glow",
                        description = "Monitor your health in style.",
                        originalPrice = "Rs.499",
                        discountedPrice = "Rs.399",
                        benefits = listOf("Skin Tightness", "Dry and dehydrated Skin"),
                        rating = 4.5f,
                        reviewCount = 932
                    )
                )
                ShopFlow(products = sampleProducts)
            }
        }
    }
}