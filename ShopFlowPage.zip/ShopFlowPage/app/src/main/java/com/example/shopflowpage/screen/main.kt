package com.example.shopflowpage.screen

import android.R.attr.fontFamily
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shopflowpage.R

data class Product(
    val id: String,
    val name: String,
    val imageResId: Int,
    val isBestSeller: Boolean,
    val category: String,
    val description: String,
    val originalPrice: String,
    val discountedPrice: String,
    val benefits: List<String>,
    val rating: Float,
    val reviewCount: Int
)
@Composable
fun ShopFlow(products: List<Product>) {
    val categories = listOf("All") + products.map { it.category }.distinct()
    var selectedCategory = remember { mutableStateOf("All") }
    val searchQuery = remember { mutableStateOf("") }


    val filteredProducts = products.filter {
        selectedCategory.value == "All" || it.category == selectedCategory.value

    }


    Column(modifier = Modifier.fillMaxSize()) {
        ShopBar(
            searchQuery = searchQuery.value,
            onSearchQueryChange = { searchQuery.value = it },
            onWishlistClick = { /* Handle wishlist click */ },
            onCartClick = { /* Handle cart click */ }
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                PromoBanner()
                Spacer(modifier = Modifier.height(18.dp))

                CategoryChips(
                    categories = categories,
                    selectedCategory = selectedCategory.value,
                    onCategorySelected = { selectedCategory.value = it }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(filteredProducts) { product ->
                ProductCard(product = product)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onWishlistClick: () -> Unit,
    onCartClick: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "ShopEasy",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = Color.Green,
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search...") },
                        modifier = Modifier
                            .width(200.dp)
                            .height(40.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = Color.White,
                        ),
                        trailingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.outline_manage_search_24),
                                contentDescription = "Search",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Icons
                    IconButton(
                        onClick = onWishlistClick,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Wishlist",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onCartClick,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Cart",
                            tint = Color.White
                        )
                    }
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Black
        )
    )
}

@Composable
fun CategoryChips(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories.size) { index ->
            val category = categories[index]
            FilterChip(
                selected = selectedCategory == category,
                onClick = { onCategorySelected(category) },
                label = { Text(category) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(32.dp)
            )
        }
    }
}


@Composable
fun PromoBanner() {
    Box(
        modifier = Modifier
            .width(500.dp)
            .height(280.dp)
            .padding(horizontal = 14.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.shopflowcard1),
            contentDescription = "Promotional banner",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("GET 20% OFF", color = Color.Green, fontSize = 50.sp, fontWeight = FontWeight.Bold)
            Text("GET 20% OFF", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("12–16 October", color = Color.White, fontSize = 20.sp)
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductCard(product: Product, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.7f)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.card_grey_bg_png),
                    contentDescription = "Card background",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                )
                Image(
                    painter = painterResource(id = product.imageResId),
                    contentDescription = product.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxSize()
                        .clip(RoundedCornerShape(12.dp))
                )

                if (product.isBestSeller) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(
                                color = MaterialTheme.colorScheme.onBackground,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Best Seller",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f)

            ) {
                Image(
                    painter = painterResource(id = R.drawable.card_black_shape),
                    contentDescription = "Card black shape",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {

                    Text(
                        text = product.category.uppercase(),
                        style = MaterialTheme.typography.labelLarge,
                        fontSize = 20.sp,
                        color = Color.Green,
                        modifier = Modifier
                            .fillMaxHeight()
                            .wrapContentWidth(Alignment.Start)
                    )

                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        ),
                        color = Color.White,
                        modifier = Modifier
                            .fillMaxHeight()
                            .wrapContentWidth(Alignment.Start),
                        maxLines = 2
                    )


                    Spacer(modifier = Modifier.height(16.dp))

                    ProductBenefits(product.benefits)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = product.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha =0.7f),
                        lineHeight = 18.sp,
                        modifier = Modifier
                            .fillMaxHeight()
                            .wrapContentHeight(),
                        maxLines = 3,
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = buildAnnotatedString {
                            withStyle(
                                SpanStyle(
                                    color = MaterialTheme.colorScheme.primary,
                                    textDecoration = TextDecoration.LineThrough,
                                    fontSize = 16.sp
                                )
                            )
                            { append(product.originalPrice) }
                            append(" ")
                            withStyle (
                                SpanStyle(
                                    color = Color(0xFF00C853),
                                    fontSize = 18.sp
                                )
                            )
                            {
                                append(" ${product.discountedPrice}")
                            }
                        },
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        repeat(5) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color(0xFF9F8C29),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${product.reviewCount} reviews",
                            style = MaterialTheme.typography.labelLarge,
                            fontSize = 14.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Preview
@Composable
fun ProductBenefits(benefits: List<String>) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        benefits.forEach { benefit ->
            Text(
                text = benefit,
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ProductCardPreview() {
    MaterialTheme {
        ProductCard(
            product = Product(
                id = "1",
                name = "French Clay Cleanser",
                imageResId = R.drawable.categorysample, // Your product image
                isBestSeller = true,
                category = "Skincare",
                description = "Clay and algae-powered cleanser",
                originalPrice = "$49.99",
                discountedPrice = "$39.99",
                benefits = listOf("Dry Skin", "Sensitive"),
                rating = 4.8f,
                reviewCount = 1284
            )
        )
    }
}